jQuery(document).ready(function ($) {

  $('#checkbox').change(function(){
    setInterval(function () {
        moveRight();
    }, 3000);
  });

    var slideCount = $('#slider ul li').length;
    var slideWidth = $('#slider ul li').width();
    var slideHeight = $('#slider ul li').height();
    var sliderUlWidth = slideCount * slideWidth;

    $('#slider').css({ width: slideWidth, height: slideHeight });

    $('#slider ul').css({ width: sliderUlWidth, marginLeft: - slideWidth });

    $('#slider ul li:last-child').prependTo('#slider ul');

    function moveLeft() {
        $('#slider ul').animate({
            left: + slideWidth
        }, 200, function () {
            $('#slider ul li:last-child').prependTo('#slider ul');
            $('#slider ul').css('left', '');
        });
    };

    function moveRight() {
        $('#slider ul').animate({
            left: - slideWidth
        }, 200, function () {
            $('#slider ul li:first-child').appendTo('#slider ul');
            $('#slider ul').css('left', '');
        });
    };

    $('a.control_prev').click(function () {
        moveLeft();
    });

    $('a.control_next').click(function () {
        moveRight();
    });

});



//
// var feedbackBtn = document.querySelector('.company-feedback-btn');
// var feedbackPopup = document.querySelector('.feedback');
// var feedbackClose = document.querySelector('.feedback-close');
// var feedbackCancel = document.querySelector('.feedback-cancel');
//
// if(feedbackPopup != null &&
//     feedbackClose != null &&
//     feedbackCancel != null) {
//     // добавляем событие на элемент
//     feedbackBtn.addEventListener('click', function (event) {
//        // прерываем событие по умолчанию
//         event.preventDefault();
//         // Добавляем класс
//         // classList - объект для работы с классами
//         feedbackPopup.classList.add('show-block');
//     });
//
//     feedbackClose.addEventListener('click', function (event) {
//         event.preventDefault();
//         feedbackPopup.classList.remove('show-block');
//     })
//
//     feedbackCancel.addEventListener('click', function (event) {
//         event.preventDefault();
//         feedbackPopup.classList.remove('show-block');
//     })
//
//     window.addEventListener('keydown', function (event) {
//         if(event.keyCode == 27) {
//             feedbackPopup.classList.remove('show-block');
//         }
//     });
//
//     window.addEventListener('click', function (event) {
//         if (event.target.closest(".show-block")) {
//             feedbackPopup.classList.remove('show-block');
//         }
//     });
// }

//
//
// var feedbackBtn = document.querySelectorAll('.catalog-item-buy');
// for (i = 0; i < buyItemButtons.length; ++i) {
//     feedbackBtn[i].addEventListener("click", function (event) {
//         event.preventDefault(event);
//         cartBlock.classList.add("show-block");
//     })
// }