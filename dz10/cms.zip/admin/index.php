<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>
    <a href="/admin/posts.php">Мои посты</a>
    <a href="/admin/create_post.php">Добавление</a>
    <a href="/admin/delete_post.php">Удаление</a>
    <a href="/admin/update_post.php">Изменение</a>
</body>

</html>
