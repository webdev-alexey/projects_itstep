<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin panel</title>
</head>
<body>
    <h1>Hello user!</h1>
    <a href="/admin/index.php">Админ панель</a>
</body>
</html>