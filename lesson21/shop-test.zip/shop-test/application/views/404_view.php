<div class="content_area_left">
    <section class="error_sec">
        <section class="h1">Ошибка 404</section>
        <p class="error_text">Запрашиваемый вами документ не найден</p>
        <p>Проверьте правильность набранного адреса или <a href="/">перейдите на главную страницу</a></p>
    </section>
</div>