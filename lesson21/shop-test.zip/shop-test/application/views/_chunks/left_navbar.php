<div class="categories accordeon">
    <div class="categories_title">Продукция</div>
    <ul class="categories_list accordeon_list">
        <li class="open_as_default">
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Бытовая техника</span>
                    </a>
                </div>
                <ul class="categories_item_sublist accordeon_content">
                    <li class="with_popup">
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                        <div class="categories_sublist_popup">
                            <div class="categories_popup_inner">
                                <ul class="categories_popup_list">
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>чайники</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты обыкновенные</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <a class="categories_popup_close" href="#"></a>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для дома</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для индивидуального ухода</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Посуда</span>
                    </a>
                </div>
                <ul class="categories_item_sublist accordeon_content">
                    <li class="with_popup">
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                        <div class="categories_sublist_popup">
                            <div class="categories_popup_inner">
                                <ul class="categories_popup_list">
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>чайники</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <a class="categories_popup_close" href="#"></a>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Предметы интерьера</span>
                    </a>
                </div>
                <ul class="categories_item_sublist accordeon_content">
                    <li class="with_popup">
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                        <div class="categories_sublist_popup">
                            <div class="categories_popup_inner">
                                <ul class="categories_popup_list">
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>чайники</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <a class="categories_popup_close" href="#"></a>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                </ul>
            </div>
        </li>
        <li class="non_subcategories">
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Климатическое оборудование</span>
                    </a>
                    <span class="categories_sublist_counter">14</span>
                </div>
            </div>
        </li>
        <li>
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Инструмент и оборудование</span>
                    </a>
                </div>
                <ul class="categories_item_sublist accordeon_content">
                    <li class="with_popup">
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                        <div class="categories_sublist_popup">
                            <div class="categories_popup_inner">
                                <ul class="categories_popup_list">
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>чайники</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <a class="categories_popup_close" href="#"></a>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="categories_list_item">
                <div class="categories_item_title">
                    <a href="#">
                        <span>Садово-огородный инвентарь</span>
                    </a>
                </div>
                <ul class="categories_item_sublist accordeon_content">
                    <li class="with_popup">
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                        <div class="categories_sublist_popup">
                            <div class="categories_popup_inner">
                                <ul class="categories_popup_list">
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>чайники</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="categories_sublist_inner">
                                            <a class="categories_inner_title" href="#">
                                                <span>термопоты</span>
                                            </a>
                                            <span class="categories_sublist_counter">14</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <a class="categories_popup_close" href="#"></a>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                    <li>
                        <div class="categories_sublist_inner">
                            <a class="categories_inner_title" href="#">
                                <span>Для кухни</span>
                            </a>
                            <span class="categories_sublist_counter">14</span>
                        </div>
                    </li>
                </ul>
            </div>
        </li>
    </ul>
</div>