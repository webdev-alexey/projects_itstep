<section class="features_sale">
    <div class="feautures_green_back"></div>
    <div class="feautures_sale_product">
        <img src="/images/content/holy_meat_destroyer.png" alt="">
    </div>
    <div class="feautures_sale_mask"></div>
    <div class="feautures_sale_descript">
        <a href="#">Сезонная распродажа техники для кухни</a>
    </div>
    <div class="feautures_sale_stripe"></div>
</section>