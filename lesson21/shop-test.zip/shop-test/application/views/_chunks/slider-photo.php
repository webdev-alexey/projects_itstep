<section>
    <div class="wrap">

        <ul class="wrap__slider">
            <li class="wrap__slider-item">
                <img class="wrap__slider-img" src="http://lorempixel.com/600/300/sports/1" alt=""/>
            </li>
            <li class="wrap__slider-item">
                <img class="wrap__slider-img" src="http://lorempixel.com/600/300/sports/2" alt=""/>
            </li>
            <li class="wrap__slider-item">
                <img class="wrap__slider-img" src="http://lorempixel.com/600/300/sports/3" alt=""/>
            </li>
            <li class="wrap__slider-item">
                <img class="wrap__slider-img" src="http://lorempixel.com/600/300/sports/4" alt=""/>
            </li>
        </ul>

    </div>
</section>