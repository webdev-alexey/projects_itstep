<header class="banner">
    <div class="banner_logo">
        <a href="/">
            <img src="/images/logo/main.png" alt="">
        </a>
        <span class="banner_seo_text">Оптовый магазин бытовой техники elDelta</span>
    </div>
    <div class="banner_title">
        Оптовый магазин бытовой техники
    </div>
    <div class="banner_phone">
        <a class="banner_phone-link" href="tel:+84955466590">
            <span>8(495)</span>
            <span>546-65-90</span>
        </a>
    </div>
</header>