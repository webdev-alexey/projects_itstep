<section class="h1">Контакты</section>
<section class="address">
    <div class="contacts_title">Наш адрес</div>
    <div class="address_direction">
        <span>346720, Ростовская область, г. Аксай , ул. Промышленная №10.</span>
        <span>Телефоны: (8-86350) 5-20-10, 5-54-71, 5-50-12</span>
    </div>
    <div class="address_map">
        <div id="ymaps-map-id_136360048834677272460" style="width: 647px; height: 326px;"></div>
        <script type="text/javascript">function fid_136360048834677272460(ymaps) {var map = new ymaps.Map("ymaps-map-id_136360048834677272460", {center: [39.852977256591814, 47.28125410574537], zoom: 14, type: "yandex#map"});map.controls.add("zoomControl").add("mapTools").add(new ymaps.control.TypeSelector(["yandex#map", "yandex#satellite", "yandex#hybrid", "yandex#publicMap"]));};</script>
        <script type="text/javascript" src="http://api-maps.yandex.ru/2.0-stable/?lang=ru-RU&coordorder=longlat&load=package.full&wizard=constructor&onload=fid_136360048834677272460"></script>
        <div class="addres_lt"></div>
        <div class="addres_rt"></div>
        <div class="addres_lb"></div>
        <div class="addres_rb"></div>
        <div class="addres_left"></div>
        <div class="addres_right"></div>
        <div class="addres_top"></div>
        <div class="addres_bottom"></div>
    </div>
</section>
<section class="managers">
    <div class="contacts_title">Региональные менеджеры</div>
    <ul class="managers_list">
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
        <li>
            <div class="mangers_pic">
                <div class="managers_pic_wrap">
                    <img src="/images/content/manager.png" alt="">
                </div>
                <div class="managers_pic_frame"></div>
            </div>
            <div class="managers_title">
                <div class="managers_title_name">Иванов</div>
                <div class="managers_title_surname">Иван Петрович</div>
                <div class="managers_title_state">Санкт-Петербург</div>
            </div>
            <ul class="managers_contacts">
                <li>
                    <div class="managers_contacts_phone">
                        Тел.: <span>8 (499) 123-45-67</span>
                    </div>
                    <div class="managers_contacts_icq">
                        ICQ: <span>12345677</span>
                    </div>
                </li>
            </ul>
        </li>
    </ul>
</section>
<section class="feedback">
    <div class="contacts_title">Свяжитесь с нами</div>
    <form action="" method="post">
        <div class="feedback_form_field">
            <div class="text_input">
                <div class="text_input_wrap">
                    <input type="text" placeholder="ФИО" class="feedback_input">
                </div>
            </div>
            <div class="feedback_require_star"></div>
        </div>
        <div class="feedback_form_field">
            <div class="text_input">
                <div class="text_input_wrap">
                    <input type="text" placeholder="Телефон" class="feedback_input">
                </div>
            </div>
        </div>
        <div class="feedback_form_field">
            <div class="text_input">
                <div class="text_input_wrap">
                    <input type="text" placeholder="E-MAIL" class="feedback_input">
                </div>
            </div>
            <div class="feedback_require_star"></div>
        </div>
        <div class="feedback_form_field">
            <textarea class="feedback_massage" placeholder="Текст сообщения"></textarea>
            <div class="feedback_require_star"></div>
        </div>
        <div class="feedback_submit_block">
            <a href="#" class="feedback_submit_btn">Отправить</a>
            <input type="submit">
        </div>
    </form>
</section>