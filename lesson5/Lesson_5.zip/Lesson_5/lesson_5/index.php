<?php

    require_once 'header.php';
?>

<section class="slider">
    <div class="container">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="https://fakeimg.pl/350x200/?text=World&font=lobster">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="https://fakeimg.pl/350x200/?text=World&font=lobster" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="https://fakeimg.pl/350x200/?text=World&font=lobster"" alt="Third slide">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</section>

<!-- Modal -->
<?php

require_once 'footer.php';
?>