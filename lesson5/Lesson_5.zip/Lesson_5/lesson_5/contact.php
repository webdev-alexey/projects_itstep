<?php

require_once 'header.php';
?>

    <section class="news">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src=".../100px180/?text=Image cap" alt="Card image cap">
                        <div class="card-body">
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src=".../100px180/?text=Image cap" alt="Card image cap">
                        <div class="card-body">
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src=".../100px180/?text=Image cap" alt="Card image cap">
                        <div class="card-body">
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card" style="width: 18rem;">
                        <img class="card-img-top" src=".../100px180/?text=Image cap" alt="Card image cap">
                        <div class="card-body">
                            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php

require_once 'footer.php';
?>

