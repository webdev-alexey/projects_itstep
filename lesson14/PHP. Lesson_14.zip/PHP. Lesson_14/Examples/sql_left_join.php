<?php
include "db.php";
// SQL LEFT JOIN

$query = "SELECT * FROM Authors LEFT JOIN Books ON Authors.AuthorID = Books.BookID";

$query_result = mysqli_query($connection, $query);

foreach ($query_result as $value) {
  echo $value['AuthorName'] . " - ";
  echo $value['BookName'] . "<br>";
}