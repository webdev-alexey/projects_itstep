<?php
include "db.php";
// SQL FULL JOIN

$query = "SELECT * FROM Authors FULL JOIN Books ON Authors.AuthorID = Books.BookID";

$query_result = mysqli_query($connection, $query);

foreach ($query_result as $value) {
  echo $value['AuthorName'] . " - ";
  echo $value['BookName'] . "<br>";
}