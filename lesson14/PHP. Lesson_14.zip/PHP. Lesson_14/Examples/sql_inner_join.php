<?php
include "db.php";
// SQL INNER JOIN

$query = "SELECT * FROM Authors INNER JOIN Books ON Authors.AuthorID = Books.BookID";

$query_result = mysqli_query($connection, $query);

foreach ($query_result as $value) {
  echo $value['AuthorName'] . " - ";
  echo $value['BookName'] . "<br>";
}