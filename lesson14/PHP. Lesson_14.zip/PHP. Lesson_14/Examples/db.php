<?php

$connection = mysqli_connect('localhost', 'root', '', 'sql');

if (!$connection) {
  die('Failed');
}