<?php
header('Cache-Control: max-age=3600');
echo date('d.m.Y H:i:s');