<?php

header('HTTP/1.1 307 Temporary Redirect');
header('Location: http://itstep.by');