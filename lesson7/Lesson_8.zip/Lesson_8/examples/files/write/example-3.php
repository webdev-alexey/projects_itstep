<?php

file_put_contents('some-txt', 'Тестовая строка'.PHP_EOL, FILE_APPEND);