<?php
    //echo 'Запрашиваемый url ' . $_SERVER['QUERY_STRING'];
    //index.php => /
    //index.php?/posts = /?/posts => posts
    //RewriteEngine On
    //require '../Core/Router.php';
    //__DIR__
    spl_autoload_register(function($class){
        //получаем родительскую директорию
        $root = dirname(__DIR__);
        $file = $root . '/' . str_replace('\\','/',$class) . '.php';
        if(is_readable($file)){
            include $file;
        }
    });

    $router = new Core\Router();

    echo get_class($router);

    $router->add('/', ['Controller' => 'Home', 'action' => 'index']);
    $router->add('posts', ['Controller' => 'Posts', 'action' => 'index']);
    $router->add('posts/show', ['Controller' => 'Posts', 'action' => 'show']);

    //Отобразить роуты
//    echo '<pre>';
//    var_dump($router->getRoutes());
//    echo '</pre>';
    $url = $_SERVER['QUERY_STRING'];
    if($router->match($url)){
        echo '<pre>';
        var_dump($router->getRoutes());
        echo '</pre>';
    }
?>