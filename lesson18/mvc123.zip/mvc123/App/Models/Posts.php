<?php

namespace Models;

class Post{
    public function get(){   
        $sql = 'SELECT * FROM users';
    }

}
?>