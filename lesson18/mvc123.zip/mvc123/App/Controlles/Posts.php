<?php

namespace App\Controllers;

class Posts{
    public function show(){
        echo 'I\'m function show';
    }
    public function index(){
        echo 'I\'m function index';
    }
}

?>