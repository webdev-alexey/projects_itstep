<?php
namespace Core;

class Router{
    //роуты
    protected $routes = [];
    protected $params = [];
    //метод добавления роутов
    public function add($route, $params){
        $this->routes[$route] = $params;
    }
    public function getRoutes(){
        return $this->routes;
    }

    public function match($url){
        foreach ($this->routes as $route => $params){
            if($url == $route){
                $this->params = $params;
                return true;
            }
        }
        return false;
    }
}
