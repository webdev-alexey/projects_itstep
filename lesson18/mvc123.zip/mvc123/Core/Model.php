<?php
namespace Models;

class Model{
    public function getData(){
        $connection = mysql_connect('localhost', 'root', '', 'cms');
        return $connection;
    }
}